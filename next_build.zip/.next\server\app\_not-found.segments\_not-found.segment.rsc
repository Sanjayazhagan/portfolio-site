1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
3:I[837457,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"47I7XNoruRiyV5h3nS9FU"}
