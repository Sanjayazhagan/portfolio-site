module.exports=[492043,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_login_page_actions_024efkc.js.map