globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/47I7XNoruRiyV5h3nS9FU/_buildManifest.js",
    "static/47I7XNoruRiyV5h3nS9FU/_ssgManifest.js",
    "static/47I7XNoruRiyV5h3nS9FU/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2_ko465099s53.js",
    "static/chunks/2pzafz57-h46r.js",
    "static/chunks/3nc6x0_y5iwnk.js",
    "static/chunks/2g05-lers809t.js",
    "static/chunks/3dektbsbvis8f.js",
    "static/chunks/turbopack-1gh5a22bmwh87.js"
  ]
};
