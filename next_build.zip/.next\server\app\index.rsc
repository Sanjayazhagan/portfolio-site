1:"$Sreact.fragment"
4:I[897367,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"OutletBoundary"]
5:"$Sreact.suspense"
7:I[897367,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"ViewportBoundary"]
9:I[897367,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"MetadataBoundary"]
b:I[168027,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default",1]
:HL["/_next/static/chunks/2z4_8va1xs_fz.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/e8f2fbee2754df70-s.p.1dqa_6e_ad4sj.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"P":null,"c":["",""],"q":"","i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2z4_8va1xs_fz.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/01xolrs9qcalz.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/25kwdl4ci5gk8.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/2nsi_8jk29oiv.js","async":true,"nonce":"$undefined"}],["$","script","script-3",{"src":"/_next/static/chunks/0w5z8mu1zze0w.js","async":true,"nonce":"$undefined"}],["$","script","script-4",{"src":"/_next/static/chunks/1ntn7efqc-iiw.js","async":true,"nonce":"$undefined"}]],"$L2"]}],{"children":[["$","$1","c",{"children":["$L3",[["$","script","script-0",{"src":"/_next/static/chunks/04yk3kcvu7ns4.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/13u01q2uy1wnj.js","async":true,"nonce":"$undefined"}]],["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],{},null,false,null]},null,false,null],["$","$1","h",{"children":[null,["$","$L7",null,{"children":"$L8"}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$La"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],false]],"m":"$undefined","G":["$b",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2z4_8va1xs_fz.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"47I7XNoruRiyV5h3nS9FU"}
8:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
c:I[27201,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"IconMark"]
6:null
a:[["$","title","0",{"children":"Sanjay Azhagan | Next.js Developer & AI Specialist"}],["$","meta","1",{"name":"description","content":"Portfolio of Sanjay Azhagan, a passionate Software Engineering Intern specializing in Next.js, React, Distributed Systems, and AI technologies. Explore my projects including VeriLaw and React applications."}],["$","link","2",{"rel":"author","href":"https://sanjayazhagan.tech"}],["$","meta","3",{"name":"author","content":"Sanjay Azhagan"}],["$","meta","4",{"name":"keywords","content":"Sanjay Azhagan,Next.js developer,React,AI,Software Engineer,Frontend Developer,Web Development,VeriLaw"}],["$","meta","5",{"name":"creator","content":"Sanjay Azhagan"}],["$","meta","6",{"name":"robots","content":"index, follow"}],["$","meta","7",{"name":"googlebot","content":"index, follow, max-video-preview:-1, max-image-preview:large, max-snippet:-1"}],["$","meta","8",{"property":"og:title","content":"Sanjay Azhagan | Next.js Developer & AI Specialist"}],["$","meta","9",{"property":"og:description","content":"Portfolio of Sanjay Azhagan, a passionate Software Engineering Intern specializing in Next.js, React, Distributed Systems, and AI technologies."}],["$","meta","10",{"property":"og:url","content":"https://sanjayazhagan.tech"}],["$","meta","11",{"property":"og:site_name","content":"Sanjay Azhagan Portfolio"}],["$","meta","12",{"property":"og:locale","content":"en_US"}],["$","meta","13",{"property":"og:type","content":"website"}],["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","15",{"name":"twitter:title","content":"Sanjay Azhagan | Next.js Developer & AI Specialist"}],["$","meta","16",{"name":"twitter:description","content":"Portfolio of Sanjay Azhagan, a passionate Software Engineering Intern specializing in Next.js, React, Distributed Systems, and AI technologies."}],["$","link","17",{"rel":"icon","href":"/icon.png?icon.2f3hd_ntp5axl.png","sizes":"844x638","type":"image/png"}],["$","$Lc","18",{}]]
d:I[818943,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"CSPostHogProvider"]
e:I[251330,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
f:I[340242,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"CustomCursor"]
10:I[472863,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"AvatarProvider"]
11:I[603374,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"Header"]
12:T1442,# VeriLaw AI — Enterprise Legal Auditing & Privacy Platform

VeriLaw AI is a secure, state-of-the-art legal auditing system designed to automatically scan corporate agreements, redact Personally Identifiable Information (PII) before it leaves the secure gateway, and audit the contract for material legal risks (such as uncapped liabilities and auto-renewal clauses).

---

## 🏛️ System Architecture

The application is built on a split-trust, privacy-first parallel architecture:

```mermaid
graph TD
    Client[React Frontend] <-->|HTTP/Auth| Gateway[Express Gateway + Privacy Scrubber]
    Gateway <-->|Drizzle ORM| DB[(Neon PostgreSQL)]
    Gateway -->|HTTP Triggers| FastAPI[FastAPI Triage Node]
    FastAPI -->|Enqueue Job| Redis[(Upstash Redis Queue)]
    Redis <-->|BRPOP / Processing| Workers[LangGraph background Workers]
    Workers -->|Save Findings| DB
```

### 1. Secure Privacy Gateway (Node.js Express)
* **Text Extraction:** Uses `pdf-parse` to extract clean text from uploaded files (PDFs, TXT, OCR-ready images).
* **Privacy Scrubber:** Runs a fast, local Regex engine to anonymize emails, phone numbers, tax IDs, and corporate entity/personal names. Replaces PII with secure keys (e.g. `[REDACTED_NAME_1]`) before sending data to any external LLMs.
* **Database:** Powered by Drizzle ORM connecting to a Neon PostgreSQL database. Stores users, document metadata, PII mappings, and audit results.

### 2. Risk Language Model (FastAPI + LangGraph)
* **Intelligent Router:** Classifies contract types (MSA, NDA, SOW) and runs triage to determine complexity (using `llama-3.1-8b-instant`).
* **Map-Reduce Auditing:** Splices the document text into pages and fans them out to background workers in parallel.
* **Worker LLMs:** Standard or low-risk documents run on `llama-3.1-8b-instant`, while complex or high-risk contracts utilize `llama-3.3-70b-versatile` via Groq.
* **Synthesis & Save:** Merges worker findings, filters out hallucinations, and writes the final markdown executive summary and categorized risk list directly back to the Neon PostgreSQL database.

---

## 🛠️ Technology Stack

| Component | Technologies |
|---|---|
| **Frontend** | React, TypeScript, Vite, Vanilla CSS, Lucide Icons |
| **Gateway Service** | Node.js, Express, Multer, Drizzle ORM |
| **Microservice** | Python, FastAPI, LangGraph, Pydantic |
| **Message Queue** | Redis (supports Upstash Redis / local Redis) |
| **Database** | PostgreSQL (Neon serverless Postgres) |
| **LLM Provider** | Groq Cloud APIs (`llama-3.1-8b-instant` / `llama-3.3-70b-versatile`) |

---
**The Struggle:** 
Initially, we deployed the Express Gateway and Python FastAPI microservice to **Render.com** (Oregon region). However, our primary LLM provider, **Groq**, strictly blocked API requests originating from Render's IP addresses due to geographic/datacenter restrictions. This caused all backend API calls to silently fail with `403` or rate limit errors.

**The Decision:**
1. **Switched AI Providers:** We migrated the entire LLM pipeline from Groq directly to **OpenRouter**. OpenRouter acts as an unrestricted proxy, giving us access to the exact same models (like `gemma-4-26b-a4b-it:free` and `llama-3`) without the harsh geographic IP blocks.
2. **Moved to a Private Azure VM:** We abandoned the managed Render.com deployment and moved all hosting to a private Azure Ubuntu VM. This gave us a dedicated IP address (bypassing blocks) and allowed us to run Redis locally via Docker (zero network latency for the background workers) instead of relying on Upstash.

## 2. Worker Error Bubbling & UI Diagnostics
**The Struggle:**
Because the architecture is heavily asynchronous (Express -> FastAPI -> Redis -> Python Worker), when an AI request failed (e.g. rate limits, invalid API keys), the background worker would crash silently. The frontend React UI would just say "Processing" forever or show a generic "Failed" state. Users had no idea *why* a document failed without SSHing into the server to read terminal logs.

**The Decision:**
Instead of running a complex database migration to add an `error_message` column, we decided to hijack the existing `progress_step` text column. We modified the LangGraph Python worker to explicitly catch `RateLimitError` and `AuthError`, format them into human-readable strings (e.g., `[AI Error] OpenRouter Rate Limit Exceeded`), and save them directly to `progress_step`. The React frontend now polls this column and immediately fires a browser alert to inform the user exactly what went wrong before auto-deleting the failed row.

## 3. Handling Corrupted PDFs
**The Struggle:**
Certain scanned or digitally signed PDFs were causing the `pdf-parse` library to crash completely with a `bad XRef entry` error. Because this happened before the text ever reached the AI, the backend threw a cryptic 500 Server Error.

**The Decision:**
We wrapped the PDF parsing logic in an explicit `try/catch` block. Rather than rewriting the entire parser to use a heavier library, we intercept the `bad XRef entry` error and return a friendly, actionable message instructing the user to "Print -> Save as PDF" to flatten the document, bypassing the corruption.13:T114e,# Qwen-GRPO Math Reasoner — RLAIF Fine-Tuning Pipeline

This project fine-tunes the Qwen2.5-0.5B-Instruct model on the GSM8K dataset to solve grade-school math problems[cite: 1]. The methodology utilizes the `verifiers` package to programmatically reward the model for correct calculations and strict tag formatting[cite: 1]. Optimized for a Kaggle environment, this targeted training successfully boosted the model's format compliance to 100% and its mathematical accuracy to 48%[cite: 1].

---

## 🏛️ Training Architecture

The pipeline is built on a Reinforcement Learning from AI Feedback (RLAIF) approach using Group Relative Policy Optimization (GRPO)[cite: 1]:

```mermaid
graph TD
    Data[GSM8K Dataset] -->|Extract Ground Truth| Formatting[Prompt Formatting]
    Formatting -->|System Prompt Setup| Trainer[TRL GRPOTrainer]
    Trainer <-->|Generate Completions| Model[Qwen2.5-0.5B-Instruct]
    Model -->|Output| Verifier[Reward Functions]
    Verifier -->|Check XML Tags| FormatReward[Format Score 0.0 or 1.0]
    Verifier -->|Regex Match| MathReward[Correctness Score 0.0 or 1.0]
    FormatReward --> Trainer
    MathReward --> Trainer
    Trainer -->|Save Weights| Disk[Fine-Tuned Checkpoint]
```

### 1. Dataset & Tokenization
* **Prompt Filtering:** Extracts questions from the `openai/gsm8k` dataset and strictly enforces a 256-token prompt budget to maintain memory efficiency[cite: 1].
* **Left-Padding:** Configures the tokenizer to use left-padding, ensuring batched autoregressive generation aligns correctly for GRPO[cite: 1].
* **System Prompting:** Instructs the model to output step-by-step reasoning inside `<thinking>` tags, followed strictly by the final numeric answer inside `<answer>` tags[cite: 1].

### 2. Reward Verification System
* **Format Reward:** Uses the `verifiers` XML parser to check for the presence of valid `<thinking>` and `<answer>` tags[cite: 1].
* **Correctness Reward:** Programmatically compares the extracted numeric answer to the deterministic GSM8K ground truth, normalizing numbers to avoid false penalties on string formatting (e.g., stripping commas and symbols)[cite: 1].
* **No LLM Judge:** By using deterministic programmatic verification, the training avoids the overhead and latency of using an LLM-as-a-judge[cite: 1].

---

## 🛠️ Technology Stack

| Component | Technologies |
| :--- | :--- |
| **Base Model** | `Qwen/Qwen2.5-0.5B-Instruct`[cite: 1] |
| **Dataset** | `openai/gsm8k`[cite: 1] |
| **Training Framework** | `trl` (GRPOTrainer), `transformers`, `accelerate`[cite: 1] |
| **Verification Engine** | `verifiers` (XMLParser)[cite: 1] |
| **Hardware** | Kaggle T4 x2 (2 x 16GB Turing GPUs)[cite: 1] |
| **Precision** | fp16 mixed precision[cite: 1] |

---

## 💡 Challenges & Architectural Decisions

### 1. Overcoming Free-Tier RAM Limitations
**The Struggle:**
Initially, we attempted to run the fine-tuning pipeline on the free tier of Google Colab. However, compiling the model with mixed precision and retaining multiple generated completions in memory simultaneously for the policy-gradient update quickly exceeded the standard RAM limit. This caused the kernel to repeatedly crash with Out-Of-Memory (OOM) errors before the first epoch could finish.

**The Decision:**
We migrated the entire environment to a **Kaggle T4 x2 runtime**, giving us access to two 16GB Turing GPUs[cite: 1]. To ensure it fit safely within this new memory ceiling, we configured the `GRPOTrainer` with a per-device batch size of 1, offset by `gradient_accumulation_steps=8`, and explicitly enabled `gradient_checkpointing=True` to trade compute for massive activation-memory savings[cite: 1].

### 2. Dependency Hell & Library Conflicts
**The Struggle:**
Kaggle's base image ships with a pre-installed `wandb` package whose compiled protobuf files frequently sit out of sync with the newer `protobuf` versions pulled in by fresh `transformers` and `trl` installations[cite: 1]. Even when not using external logging, the library auto-probed for WandB on import, crashing the entire script with an `ImportError`[cite: 1].

**The Decision:**
Instead of chasing down matching version pins and compiling dependencies from scratch, we opted for a clean bypass[cite: 1]. Since we set `report_to="none"` for this lightweight run, we executed a silent, forced uninstall of `wandb` right at the start of the environment setup, cleanly sidestepping the crash[cite: 1].2:["$","html",null,{"lang":"en","className":"geist_a71539c9-module__T19VSG__variable geist_mono_8d43a2aa-module__8Li5zG__variable montserrat_a6b8e55e-module__JnHUVq__variable h-full antialiased","children":["$","$Ld",null,{"children":["$","body",null,{"className":"min-h-full flex flex-col pt-24 pb-12 overflow-x-hidden text-slate-50 relative","children":[["$","$Le",null,{}],["$","$Lf",null,{}],["$","$L10",null,{"children":[["$","$L11",null,{"projects":[{"id":"1","slug":"veri-law","title":"VeriLaw","description":"VeriLaw AI is a secure, state-of-the-art legal auditing system designed to automatically scan corporate agreements, redact Personally Identifiable Information (PII) before it leaves the secure gateway, and audit the contract for material legal risks (such as uncapped liabilities and auto-renewal clauses).","pillars":["AI","CLOUD","Distributed System","FULL-STACK","DEVOPS"],"tags":"[]","link":"https://github.com/sanjay/distributed-scheduler","github":"https://github.com/Sanjayazhagan/VeriLaw-AI","linkedin":"https://www.linkedin.com/posts/sanjay-azhagan-85a8622a6_fullstack-aiengineering-langgraph-ugcPost-7469735004630339585-HoJv/?utm_source=social_share_send&utm_medium=member_desktop_web&rcm=ACoAAEnPOEYBeSqkIlGQ_yEa-6qp-mpnsK-aaL4","date":"August 2023","image":"/projects/scheduler.jpg","video":"","live":"http://sanjayazhagan.eastasia.cloudapp.azure.com/veri-law/","kaggle":null,"content":"$12","showcase":true,"createdAt":"$D2026-07-12T15:37:36.835Z","updatedAt":"$D2026-07-12T15:37:36.835Z"},{"id":"2","slug":"RLAIF-with-GRPO","title":"RLAIF with GRPO: Qwen2.5-0.5B-Instruct + verifiers (Kaggle T4 x2)","description":"This project fine-tunes the Qwen2.5-0.5B-Instruct model on the GSM8K dataset to solve grade-school math problems. The methodology utilizes the verifiers package to programmatically reward the model for correct calculations and strict tag formatting. As a result, this targeted training successfully boosts the model's format compliance to 100% and its mathematical accuracy to 48%.","pillars":["RLAIF","GRPO","Kaggle","Fine-tuning","LLM","AI"],"tags":"[]","link":"https://github.com/sanjay/ai-copilot","github":"","linkedin":"https://www.linkedin.com/posts/sanjay-azhagan-85a8622a6_machinelearning-generativeai-llm-share-7477040675537068032-51Yq/?utm_source=social_share_send&utm_medium=member_desktop_web&rcm=ACoAAEnPOEYBeSqkIlGQ_yEa-6qp-mpnsK-aaL4","date":"November 2023","image":"/projects/copilot.jpg","video":"","live":"","kaggle":"https://www.linkedin.com/safety/go/?url=https%3A%2F%2Flnkd.in%2Fggv6Sk6V&urlhash=3rIP&mt=2IMLNygJUn9fICAIn0SVmKo_xDROCXQ0o1I0UMhlfg081tnB_kboQznfqbAKV6CmBRIYEyt-kU64xlLJq3q7HUa6Nyi2hzUQoTVmY1BOiV2Yn5JkbOyajVeGC8c&isSdui=true&lipi=urn%3Ali%3Apage%3Ad_flagship3_detail_base%3BuYQreTpzQWmRU%2B2tLwGitg%3D%3D","content":"$13","showcase":true,"createdAt":"$D2026-07-12T15:37:36.840Z","updatedAt":"$D2026-07-12T15:37:36.840Z"},{"id":"3","slug":"yield-aggregator","title":"DeFi Yield Aggregator","description":"A Web3 smart contract protocol to automatically compound yields across multiple chains.","pillars":["Web3","Full-Stack"],"tags":"[]","link":"https://github.com/sanjay/yield-aggregator","github":"https://github.com/sanjay/yield-aggregator","linkedin":"https://linkedin.com/posts/sanjay_post3","date":"February 2024","image":"/projects/web3.jpg","video":"https://www.youtube.com/embed/dQw4w9WgXcQ","live":"https://yield-aggregator-demo.com","kaggle":null,"content":"### The Problem\n\nYield farming across multiple chains requires manually bridging, swapping, and staking tokens which costs high gas fees.\n\n### The Solution\n\nThis protocol automatically routes funds to the highest-yielding pools across Ethereum, Arbitrum, and Polygon.\n\n### Tech Stack\n\n- Solidity (Smart Contracts)\n- Next.js / React (Frontend)\n- Ethers.js / Wagmi","showcase":true,"createdAt":"$D2026-07-12T15:37:36.846Z","updatedAt":"$D2026-07-12T15:37:36.846Z"},{"id":"4","slug":"infra-cli","title":"Cloud Infrastructure Provisioner","description":"Automated infrastructure-as-code CLI tool for multi-cloud deployments.","pillars":["Cloud","Full-Stack"],"tags":"[]","link":"https://github.com/sanjay/infra-cli","github":"https://github.com/sanjay/infra-cli","linkedin":"https://linkedin.com/posts/sanjay_post4","date":"May 2024","image":"/projects/cloud.jpg","video":"https://www.youtube.com/embed/dQw4w9WgXcQ","live":"https://infra-cli-docs.com","kaggle":null,"content":"### Why I Built This\n\nManaging Terraform states for multi-region architectures was becoming a nightmare. This CLI abstracts the complexity of Terraform into simple YAML configuration files.\n\n### Key Features\n\n- **Multi-Cloud:** Supports AWS, GCP, and Azure out of the box.\n- **State Management:** Encrypted remote state locks.\n- **Rollbacks:** Instant rollback to previous infrastructure states.\n\n### Tech Stack\n\n- Go (Golang)\n- Cobra CLI\n- Terraform SDK","showcase":true,"createdAt":"$D2026-07-12T15:37:36.851Z","updatedAt":"$D2026-07-12T15:37:36.851Z"}],"pillars":[{"id":"ai","title":"AI","summary":"Exploring the intersection of LLMs, agentic workflows, and real-world utility.","philosophy":"I prioritize building AI systems that augment human capabilities safely and transparently.","createdAt":"$D2026-07-12T15:37:36.857Z","updatedAt":"$D2026-07-12T15:37:36.857Z","logs":[{"id":"log-2","date":"2026-06-01","title":"Launched AI Copilot","type":"Project Build","content":"Deployed the first version of the AI IDE extension.","link":"https://github.com/sanjay/ai-copilot","github":null,"linkedin":null,"live":null,"kaggle":null,"pillars":"[\"ai\"]","projectIds":"[]","createdAt":"$D2026-07-12T15:37:36.868Z","updatedAt":"$D2026-07-12T15:37:36.868Z"},{"id":"log-1","date":"2026-05-15","title":"Fine-Tuning Llama 3 for Code Generation","type":"Learning","content":"Spent the weekend exploring fine-tuning techniques for local code generation.\n\n### Why Llama 3?\nI chose the 8B parameter model because it offers the perfect balance of reasoning capability and VRAM requirements for local execution. Running inference on a single RTX 4090 was surprisingly smooth.\n\n### The Pipeline\n- Data Collection: Curated a dataset of 10k highly-rated open-source React components.\n- Pre-processing: Stripped out comments and standardized formatting.\n- LoRA Configuration: Set rank to 16 and alpha to 32.\n\n### Results\nAfter 4 epochs, the model successfully learned to output tailwind classes matching my specific design system. However, context window limitations meant it struggled with multi-file architectures. Next up: RAG integration!\n\n### Next Steps\n1. Build an LSP integration\n2. Test on a 70B model via cloud API\n3. Publish findings","link":null,"github":null,"linkedin":null,"live":null,"kaggle":null,"pillars":"[\"ai\"]","projectIds":"[]","createdAt":"$D2026-07-12T15:37:36.862Z","updatedAt":"$D2026-07-12T15:37:36.862Z"}]},{"id":"full-stack","title":"Full-Stack","summary":"Building performant, accessible, and beautiful web experiences.","philosophy":"Why I prioritize Rust in the backend and React/Next.js on the frontend.","createdAt":"$D2026-07-12T15:37:36.873Z","updatedAt":"$D2026-07-12T15:37:36.873Z","logs":[{"id":"log-3","date":"2025-10-10","title":"Migrating to Next.js App Router","type":"Learning","content":"Deep dive into RSCs and server actions.","link":null,"github":null,"linkedin":null,"live":null,"kaggle":null,"pillars":"[\"full-stack\"]","projectIds":"[]","createdAt":"$D2026-07-12T15:37:36.879Z","updatedAt":"$D2026-07-12T15:37:36.879Z"}]},{"id":"cloud","title":"Cloud","summary":"Designing resilient distributed systems for global scale.","philosophy":"Infrastructure as code is the only way to scale sustainably.","createdAt":"$D2026-07-12T15:37:36.885Z","updatedAt":"$D2026-07-12T15:37:36.885Z","logs":[]},{"id":"web3","title":"Web3","summary":"Building decentralized, trustless financial infrastructure.","philosophy":"Smart contracts must be formally verified and aggressively audited.","createdAt":"$D2026-07-12T15:37:36.890Z","updatedAt":"$D2026-07-12T15:37:36.890Z","logs":[]}]}],"$L14"]}]]}]}]}]
15:I[339756,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
16:I[837457,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
17:I[920234,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/04yk3kcvu7ns4.js","/_next/static/chunks/13u01q2uy1wnj.js"],"HomeContent"]
14:["$","main",null,{"className":"flex-1 w-full max-w-[1600px] mx-auto px-4 md:px-8 lg:px-12","children":["$","$L15",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L16",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]
3:["$","$L17",null,{"projects":"$2:props:children:props:children:props:children:2:props:children:0:props:projects","pillars":"$2:props:children:props:children:props:children:2:props:children:0:props:pillars","experiences":[{"id":"cmri0izay0005zq85dn6tu41h","role":"Fullstack Developer Intern","company":"Montra Electric","period":"2026 May - July","description":"* Architected microservices using distributed systems and multi-threading, engineering solutions for high scalability supporting 50+ users.\n* Implemented concurrency and synchronization controls to optimize backend task distribution.\n* Collaborated across teams to foster a culture of innovation, integrating AI features to improve system observability, reliability, and performance.","createdAt":"$D2026-07-12T16:33:29.914Z","updatedAt":"$D2026-07-12T16:33:29.914Z"},{"id":"cmri0izb30006zq85217n559t","role":"Fullstack dev intern","company":"DM8","period":"2025 Dec - 2026 may","description":"* Led end-to-end development of a freelance platform utilizing SvelteKit, demonstrating strong time management and project delivery skills.\n* Engineered backend modules for user management; converted complex UI requirements into responsive, high-quality functional code.","createdAt":"$D2026-07-12T16:33:29.919Z","updatedAt":"$D2026-07-12T16:33:29.919Z"}]}]
