var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate-resume/route.js")
R.c("server/chunks/[externals]__1qydqyz._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1fool7g.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__163w3q6._.js")
R.c("server/chunks/_next-internal_server_app_api_generate-resume_route_actions_0_tl2wp.js")
R.m(357725)
module.exports=R.m(357725).exports
