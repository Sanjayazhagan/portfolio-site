module.exports=[299018,a=>a.a(async(b,c)=>{try{let b=await a.y("@react-pdf/renderer-5f716e9bc7d68b8a");a.n(b),c()}catch(a){c(a)}},!0)];

//# sourceMappingURL=%5Bexternals%5D_%40react-pdf_renderer_01z2ibz._.js.map