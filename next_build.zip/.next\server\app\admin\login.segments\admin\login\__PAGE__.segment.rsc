1:"$Sreact.fragment"
2:I[244,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/1mbio7shh3gpd.js","/_next/static/chunks/3udumx7ghi22k.js"],"LoginForm"]
3:I[897367,["/_next/static/chunks/01xolrs9qcalz.js","/_next/static/chunks/25kwdl4ci5gk8.js","/_next/static/chunks/2nsi_8jk29oiv.js","/_next/static/chunks/0w5z8mu1zze0w.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen flex items-center justify-center bg-slate-950 p-4","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/3udumx7ghi22k.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"47I7XNoruRiyV5h3nS9FU"}
5:null
